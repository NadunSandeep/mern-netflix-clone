export const API_KEY = "6d75b2a2e2b05ca51b4dda2ad6426fda";
export const TMDB_BASE_URL = "https://api.themoviedb.org/3";
